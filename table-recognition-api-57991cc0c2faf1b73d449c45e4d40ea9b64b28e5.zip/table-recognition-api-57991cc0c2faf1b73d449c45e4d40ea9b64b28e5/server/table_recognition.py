#!/usr/bin/env python3
"""
PDF 表格识别脚本
使用 TableStructureRec 进行表格识别
"""

import sys
import json
import os
from pathlib import Path
from typing import Any, List, Optional

try:
    from lineless_table_rec.main import LinelessTableRecognition, LinelessTableInput
    from wired_table_rec.main import WiredTableRecognition, WiredTableInput
    from rapidocr_onnxruntime import RapidOCR
    from PIL import Image
except ImportError as e:
    print(json.dumps({
        "success": False,
        "error": f"導入模組失敗: {str(e)}"
    }, ensure_ascii=False))
    sys.exit(1)


def preprocess_image(img_path: str) -> str:
    """
    圖片預處理：自動旋轉、增強對比度、去噪
    
    Args:
        img_path: 圖片路徑
        
    Returns:
        處理後的圖片路徑
    """
    try:
        from PIL import ImageEnhance, ImageFilter
        
        img = Image.open(img_path)
        width, height = img.size
        
        # 1. 如果寬度大於高度，圖片是橫向的，需要旋轉 90 度
        if width > height * 1.2:  # 1.2 是容錯係數
            img = img.rotate(90, expand=True)
            print(f"圖片已自動旋轉: {img_path} (原尺寸: {width}x{height})", file=sys.stderr)
        
        # 2. 轉換為 RGB 模式（如果是 RGBA 或其他模式）
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # 3. 增強對比度（提高文字清晰度）
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.5)  # 增強 50%
        
        # 4. 銳化處理（讓邊緣更清晰）
        enhancer = ImageEnhance.Sharpness(img)
        img = enhancer.enhance(1.3)  # 銳化 30%
        
        # 5. 輕微去噪（使用中值濾波）
        # img = img.filter(ImageFilter.MedianFilter(size=3))
        
        # 保存處理後的圖片（覆蓋原文件）
        img.save(img_path, quality=95)
        print(f"圖片預處理完成: {img_path}", file=sys.stderr)
        
        return img_path
    except Exception as e:
        print(f"圖片預處理失敗 {img_path}: {str(e)}", file=sys.stderr)
        return img_path


def recognize_tables_from_images(image_paths: List[str]) -> dict:
    """
    從圖片中識別表格
    
    Args:
        image_paths: 圖片路徑列表
        
    Returns:
        識別結果列表
    """
    results = []
    
    # 初始化 OCR 引擎（調整參數以改善表格文字檢測）
    try:
        ocr_engine = RapidOCR(
            det_limit_side_len=1920,   # 提高解析度限制（預設 960）
            det_db_thresh=0.25,        # 降低閾值，檢測更多文字區域（預設 0.3）
            use_angle_cls=True,        # 啟用方向校正
        )
    except Exception as e:
        return {
            "success": False,
            "error": f"初始化 OCR 引擎失敗: {str(e)}"
        }
    
    # 初始化表格识别引擎（調整參數以改善密集表格的欄位檢測）
    try:
        lineless_engine = LinelessTableRecognition(LinelessTableInput())

        # 調整有線表格識別參數
        wired_input = WiredTableInput()
        wired_input.col_threshold = 10     # 降低列對齊閾值（預設 15）
        wired_input.row_threshold = 8      # 降低行對齊閾值（預設 10）
        wired_engine = WiredTableRecognition(wired_input)
    except Exception as e:
        return {
            "success": False,
            "error": f"初始化表格識別引擎失敗: {str(e)}"
        }
    
    table_index = 0
    
    for page_number, img_path in enumerate(image_paths, start=1):
        if not os.path.exists(img_path):
            continue
            
        try:
            # 執行 OCR 識別
            ocr_result: Any
            ocr_result, _ = ocr_engine(img_path)
            if not ocr_result:
                ocr_result = None
            
            # 同時嘗試有線和無線表格識別，選擇較好的結果
            try:
                lineless_result = None
                wired_result = None
                
                # 嘗試無線表格識別
                try:
                    lineless_result = lineless_engine(img_path, ocr_result)
                except Exception as e:
                    print(f"無線表格識別失敗: {str(e)}", file=sys.stderr)
                
                # 嘗試有線表格識別
                try:
                    wired_result = wired_engine(img_path, ocr_result)
                except Exception as e:
                    print(f"有線表格識別失敗: {str(e)}", file=sys.stderr)
                
                # 解析兩種結果
                lineless_rows = []
                wired_rows = []
                
                if lineless_result and lineless_result.pred_html and '<table>' in lineless_result.pred_html:
                    lineless_rows = parse_html_table(lineless_result.pred_html)
                
                if wired_result and wired_result.pred_html and '<table>' in wired_result.pred_html:
                    wired_rows = parse_html_table(wired_result.pred_html)
                
                # 選擇較好的結果（優先選擇有線表格，因為對於有邊框的表格效果更好）
                best_result = None
                best_rows = []
                result_type = ""
                confidence = 0.0
                
                # 如果有線表格有結果，優先使用
                if wired_rows and len(wired_rows) > 0 and any(len(row) > 0 for row in wired_rows):
                    best_result = wired_result
                    best_rows = wired_rows
                    result_type = "wired"
                    confidence = 0.9
                # 否則使用無線表格結果
                elif lineless_rows and len(lineless_rows) > 0 and any(len(row) > 0 for row in lineless_rows):
                    best_result = lineless_result
                    best_rows = lineless_rows
                    result_type = "lineless"
                    confidence = 0.85
                
                if best_result and best_rows and best_result.pred_html:
                
                    # 調試：輸出原始 HTML
                    print(f"\n=== 表格 {table_index} 調試信息 ===", file=sys.stderr)
                    print(f"類型: {result_type}", file=sys.stderr)
                    print(f"原始行數: {len(best_rows)}", file=sys.stderr)
                    print(f"原始列數: {max(len(row) for row in best_rows) if best_rows else 0}", file=sys.stderr)
                    print(f"HTML 長度: {len(best_result.pred_html)}", file=sys.stderr)
                    print(f"HTML 預覽: {best_result.pred_html[:300]}", file=sys.stderr)
                    print(f"原始數據（前3行）: {best_rows[:3]}", file=sys.stderr)
                    
                    # 後處理：清理常見錯誤
                    cleaned_rows = clean_table_data(best_rows)
                    
                    print(f"清理後行數: {len(cleaned_rows)}", file=sys.stderr)
                    print(f"清理後數據（前3行）: {cleaned_rows[:3]}", file=sys.stderr)
                    print("=" * 50, file=sys.stderr)
                    
                    results.append({
                        "tableIndex": table_index,
                        "pageNumber": page_number,
                        "html": best_result.pred_html,
                        "rows": cleaned_rows,
                        "confidence": confidence,
                        "type": result_type
                    })
                    table_index += 1
                        
            except Exception as table_err:
                # 記錄表格識別錯誤但繼續處理
                print(f"表格識別錯誤 {img_path}: {str(table_err)}", file=sys.stderr)
                continue
                        
        except Exception as e:
            # 記錄 OCR 錯誤但繼續處理其他圖片
            print(f"OCR 錯誤 {img_path}: {str(e)}", file=sys.stderr)
            continue
    
    return {
        "success": True,
        "tables": results,
        "totalTables": len(results)
    }


def smart_split_cell(text: str) -> List[str]:
    """
    智能分割儲存格內容
    1. 優先使用多個空格作為分隔符
    2. 檢測數字重複模式
    3. 檢測日期重複模式
    4. 檢測中文+數字重複（如：已付126,300未付126,300）
    
    Args:
        text: 待分割的字串
        
    Returns:
        分割後的列表
    """
    import re
    
    if not text or len(text) < 2:
        return [text]
    
    # 方法1：使用多個空格分割（最常見的情況）
    if '  ' in text:  # 至少 2 個空格
        parts = re.split(r'\s{2,}', text)
        cleaned_parts = [p.strip() for p in parts if p.strip()]
        if len(cleaned_parts) > 1:
            print(f"🔍 使用空格分割: '{text[:50]}...' -> {len(cleaned_parts)} 列", file=sys.stderr)
            return cleaned_parts
    
    # 方法2：檢測單個空格，但要確保前後都是內容（更激進的分割）
    if ' ' in text:
        # 嘗試用單空格分割，但要過濾空結果
        parts = text.split(' ')
        # 合併連續的短片段（可能是一個詞的一部分）
        merged_parts = []
        temp = ""
        for part in parts:
            if not part:
                continue
            # 如果是數字或長度>2的文字，視為獨立單元
            if part.replace(',', '').isdigit() or len(part) > 2:
                if temp:
                    merged_parts.append(temp.strip())
                    temp = ""
                merged_parts.append(part)
            else:
                temp += (' ' if temp else '') + part
        if temp:
            merged_parts.append(temp.strip())
        
        if len(merged_parts) > 1:
            print(f"🔍 使用單空格分割: '{text[:50]}...' -> {merged_parts}", file=sys.stderr)
            return merged_parts
    
    # 方法3：檢測無空格的數字重複（如 126,300126,300）
    if ' ' not in text:
        number_pattern = r'[\d,]+'
        matches = re.findall(number_pattern, text)
        
        if len(matches) >= 2:
            first_len = len(matches[0])
            similar = all(abs(len(m) - first_len) <= 2 for m in matches)
            
            if similar:
                reconstructed = ''.join(matches)
                if reconstructed == text:
                    print(f"🔍 檢測到數字重複: '{text[:50]}...' -> {matches}", file=sys.stderr)
                    return matches
    
    # 方法4：檢測中文+數字組合重複（如：已付126,300未付126,300）
    if ' ' not in text:
        # 匹配：中文+數字（帶千分位）
        pattern = r'[\u4e00-\u9fff]+[\d,]+'
        matches = re.findall(pattern, text)
        if len(matches) >= 2:
            reconstructed = ''.join(matches)
            if reconstructed == text or len(reconstructed) > len(text) * 0.8:
                print(f"🔍 檢測到中文+數字重複: '{text[:50]}...' -> {matches}", file=sys.stderr)
                return matches
    
    # 方法5：檢測日期重複（如 2024/012024/02）
    if ' ' not in text:
        date_number = r'\d{4}/\d{2}'
        matches = re.findall(date_number, text)
        if len(matches) >= 2:
            reconstructed = ''.join(matches)
            if reconstructed == text:
                print(f"🔍 檢測到日期重複: '{text[:50]}...' -> {matches}", file=sys.stderr)
                return matches
    
    # 無法分割，返回原始文字
    return [text]


def clean_table_data(rows: List[List[str]]) -> List[List[str]]:
    """
    清理表格數據中的常見錯誤，並自動將粘連的列分割開
    
    Args:
        rows: 二維陣列表示的表格
        
    Returns:
        清理後的表格數據
    """
    import re
    
    # 第一步：初步清理每個儲存格（保留空格，不壓縮）
    cleaned_rows = []
    for row in rows:
        cleaned_row = []
        for cell in row:
            if not cell or cell == '':
                cleaned_row.append('-')
                continue
            
            # 只去除前後空白，不壓縮中間的空格（用於後續分列）
            cleaned_cell = cell.strip()
            
            cleaned_row.append(cleaned_cell if cleaned_cell else '-')
        
        cleaned_rows.append(cleaned_row)
    
    # 第二步：智能分割粘連的列
    expanded_rows = []
    max_cols = 0
    
    for row_idx, row in enumerate(cleaned_rows):
        expanded_row = []
        
        for cell in row:
            if cell == '-':
                expanded_row.append(cell)
                continue
            
            # 智能分割儲存格
            split_cells = smart_split_cell(cell)
            
            if len(split_cells) > 1:
                # 分割成多列
                expanded_row.extend(split_cells)
            else:
                # 保持原樣
                expanded_row.append(cell)
        
        expanded_rows.append(expanded_row)
        max_cols = max(max_cols, len(expanded_row))
    
    # 第三步：統一列數（補齊短行）
    for row in expanded_rows:
        while len(row) < max_cols:
            row.append('-')
    
    # 第四步：再次清理每個儲存格（處理分割後的數據）
    final_rows = []
    for row in expanded_rows:
        final_row = []
        for cell in row:
            if cell == '-' or not cell:
                final_row.append('-')
                continue
            
            # 去除前後空白，並壓縮內部空格為單個
            cleaned_cell = cell.strip()
            cleaned_cell = re.sub(r'\s+', ' ', cleaned_cell)
            
            # 修正帶有貨幣符號的數字粘連問題（例如：$28,476$28,476）
            currency_pattern = r'^([\$¥€£₩][\d,]+)\1+$'
            match = re.match(currency_pattern, cleaned_cell)
            if match:
                cleaned_cell = match.group(1)
            else:
                # 嘗試 NT$ 完全重複
                nt_pattern = r'^(NT\$[\d,]+)\1+$'
                match = re.match(nt_pattern, cleaned_cell)
                if match:
                    cleaned_cell = match.group(1)
                else:
                    # 處理多個貨幣符號
                    if cleaned_cell.count('$') > 1 or cleaned_cell.count('¥') > 1:
                        tokens = re.findall(r'(?:NT\$|[\$¥€£₩])[\d,]+(?:\.\d+)?', cleaned_cell)
                        if tokens:
                            cleaned_cell = tokens[0]
            
            # 修正日期粘連問題
            if re.match(r'^(\d{4}/\d{2})\d{4}/\d{2}$', cleaned_cell):
                match = re.match(r'^(\d{4}/\d{2}).*', cleaned_cell)
                if match:
                    cleaned_cell = match.group(1)
            
            final_row.append(cleaned_cell if cleaned_cell else '-')
        
        final_rows.append(final_row)
    
    print(f"✅ 分列完成：{len(rows)} 行 × {max(len(r) for r in rows)} 列 -> {len(final_rows)} 行 × {max_cols} 列", file=sys.stderr)
    
    return final_rows


def parse_html_table(html: str) -> List[List[str]]:
    """
    解析 HTML 表格為二維陣列
    
    Args:
        html: HTML 表格字串
        
    Returns:
        二維陣列表示的表格
    """
    from html.parser import HTMLParser
    
    class TableParser(HTMLParser):
        def __init__(self):
            super().__init__()
            self.rows = []
            self.current_row = []
            self.current_cell = []
            self.in_table = False
            self.in_row = False
            self.in_cell = False
            
        def handle_starttag(self, tag, attrs):
            if tag == 'table':
                self.in_table = True
            elif tag == 'tr' and self.in_table:
                self.in_row = True
                self.current_row = []
            elif tag in ['td', 'th'] and self.in_row:
                self.in_cell = True
                self.current_cell = []
            elif tag == 'br' and self.in_cell:
                # 遇到 <br> 標籤時，將當前內容作為一個獨立的列
                cell_text = ''.join(self.current_cell).strip()
                if cell_text:
                    self.current_row.append(cell_text)
                self.current_cell = []
                
        def handle_endtag(self, tag):
            if tag == 'table':
                self.in_table = False
            elif tag == 'tr' and self.in_row:
                if self.current_row:
                    self.rows.append(self.current_row)
                self.in_row = False
            elif tag in ['td', 'th'] and self.in_cell:
                cell_text = ''.join(self.current_cell).strip()
                if cell_text:
                    self.current_row.append(cell_text)
                self.in_cell = False
                
        def handle_data(self, data):
            if self.in_cell:
                self.current_cell.append(data)
    
    parser = TableParser()
    try:
        parser.feed(html)
        return parser.rows if parser.rows else [[]]
    except:
        # 如果解析失败，返回空表格
        return [[]]


def main():
    """主函式"""
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "缺少圖片路徑參數"
        }, ensure_ascii=False))
        sys.exit(1)
    
    # 獲取圖片路徑（可以是單個路徑或逗號分隔的多個路徑）
    image_paths_str = sys.argv[1]
    image_paths = [p.strip() for p in image_paths_str.split(',') if p.strip()]
    
    if not image_paths:
        print(json.dumps({
            "success": False,
            "error": "未提供有效的圖片路徑"
        }, ensure_ascii=False))
        sys.exit(1)
    
    # 執行表格識別
    result = recognize_tables_from_images(image_paths)
    
    # 輸出 JSON 結果
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
